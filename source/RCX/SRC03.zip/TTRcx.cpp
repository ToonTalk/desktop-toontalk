/* 
  TTRcx.cpp

  A ToonTalk extension to handle the LEGO MindStorms RCX

  Developed within the Weblabs project by Augusto Chioccariello, Ken Kahn, Luigi Sarti


  version Jan 28, 2003


  */

/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * The Initial Developer of this code is David Baum.
 * Portions created by David Baum are Copyright (C) 1998 David Baum.
 * All Rights Reserved.
 */
#include "stdafx.h"

#include <windows.h>
#include <process.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include "RCX_Link.h"
#include "RCX_Cmd.h"
#include "RCX_Log.h"
#include "SRecord.h"
#include "Error.h"
#include "CmdLine.h"
#include "version.h"

#ifdef CHECK_LEAKS
#include <DebugNew.h>
#endif

// some win32 consoles are lame...use stdout instead of stderr for usage, etc.
#ifdef WIN32
#define STDERR stdout
#else
#define STDERR stderr
#endif

FILE *gErrorStream = stderr;

//#define kMaxPrintedErrors	10


class AutoLink : public RCX_Link
{
public:
				AutoLink() : fSerialPort(0), fOpen(false) {}
				~AutoLink()	{ Close(); }

	RCX_Result	Open();
	void		Close();
	RCX_Result	Send(const RCX_Cmd *cmd, bool retry=true);
	
	void		SetSerialPort(const char *sp)	{ fSerialPort = sp; }

	bool		DownloadProgress(int soFar, int total);

private:
	const char*	fSerialPort;
	bool		fOpen;		
};


#define kMaxFirmware 65536
#define kOldIncludePathEnv	"NQCC_INCLUDE"
#define kNewIncludePathEnv	"NQC_INCLUDE"
#define kOptionsEnv			"NQC_OPTIONS"
#define kLowBattery		6600
#define kLow45Battery	3300

#define kRCXFileExtension ".rcx"
#define kNQCFileExtension ".nqc"



// error codes in addition to RCX_Result codes
#define kUsageError	(kRCX_LastError - 1)
#define kQuietError	(kRCX_LastError - 2)

// codes for the actions
enum
{
	kFirstActionCode = 256,
	kDatalogCode = kFirstActionCode,
	kDatalogFullCode,
	kClearMemoryCode,
	kFirmwareCode,
	kFirmware4xCode,
	kNearCode,
	kFarCode,
	kWatchCode,
	kSleepCode,
	kRunCode,
	kProgramCode,
	kMessageCode,
	kRawCode,
	kRaw1Code,
	kRemoteCode,
	kApiCode,
	kHelpCode,
	kCompileStdinCode
};

// these must be in the same order as the codes for the long options
static const char *sActionNames[] = {
	"datalog", "datalog_full", "clear", "firmware", "firmfast", "near", "far", "watch",
	"sleep", "run", "pgm", "msg", "raw", "raw1", "remote", "api", "help", ""
};

// these MUST be in the same order as the RCX_TargetType values
static const char *sTargetNames[] =
{
	"rcx",
	"cm",
	"scout",
	"rcx2",
	"spy"
};


struct Request
{
	const char *fSourceFile;
	const char *fOutputFile;
	const char *fListFile;
	bool	fListing;
	bool	fSourceListing;
	bool	fDownload;
	bool	fBinary;
	int		fFlags;
};

static int GetActionCode(const char *arg);
static RCX_Result ProcessCommandLine(int argc, char **argv);
static void mapError(RCX_Result error, char * errorString);
static void DefineMacro(const char *text);
static RCX_Result ProcessFile(const char *sourceFile, const Request &req);
static char *CreateFilename(const char *source, const char *oldExt, const char *newExt);
static const char *LeafName(const char *filename);
static int CheckExtension(const char *s1, const char *ext);
static RCX_Image *Compile(const char *sourceFile,  int flags);
static bool GenerateListing(RCX_Image *image, const char *filename, bool includeSource);
static RCX_Result Download(RCX_Image *image);
static RCX_Result UploadDatalog(bool verbose);
static RCX_Result DownloadFirmware(const char *filename, bool fast);
static RCX_Result SetWatch(const char *timeSpec);
static RCX_Result SetErrorFile(const char *filename);
static RCX_Result RedirectOutput(const char *filename);
static RCX_Result SendRawCommand(const char *text, bool retry);
static RCX_Result ClearMemory();
static RCX_Result SetTarget(const char *name);
static RCX_Result SendRemote(const char *event, int repeat);
static bool SameString(const char *s1, const char *s2);

AutoLink gLink;
RCX_TargetType gTargetType = kRCX_RCXTarget;
bool gVerbose = false;
int gTimeout = 0;



RCX_Result SetTarget(const char *name)
{
	for(unsigned int i=0; i<sizeof(sTargetNames) / sizeof(const char *); ++i)
	{
		if (SameString(name, sTargetNames[i]))
		{
			gTargetType = (RCX_TargetType)i;
			return kRCX_OK;
		}
	}

	switch(name[0])
	{
		case 'r':
		case 'R':
			gTargetType = kRCX_RCXTarget;
			break;
		case 'c':
		case 'C':
			gTargetType = kRCX_CMTarget;
			break;
		case 's':
		case 'S':
			gTargetType = kRCX_ScoutTarget;
			break;
		default:
			return kUsageError;		
	}
	
	return kRCX_OK;
}


RCX_Result SendRawCommand(const char *text, bool retry)
{
	int length = (int)strlen(text);
	RCX_Cmd cmd;
	RCX_Result result;
	
	// we need an even number of chars in text
	if (length & 1) return kUsageError;
	
	// determine actual length of command
	length /= 2;
	cmd.SetLength(length);
	
	for(int i=0; i<length; i++)
	{
		int byte = SRecord::ReadHexByte(text);
		if (byte == -1) return kUsageError;
		cmd[i] = (UByte) byte;
		text+=2;
	}
	
	result = gLink.Send(&cmd, retry);

/*
	if (result > 0)
	{
		for(int i=0; i<result; i++)
			printf("%02x ", gLink.GetReplyByte(i));
		printf("\n");
	}
  */
	
	return result;
}


int GetActionCode(const char *arg)
{
	for(int i=0; i< (int)(sizeof(sActionNames)/sizeof(const char *)); ++i)
		if (strcmp(sActionNames[i], arg)==0) return i+kFirstActionCode;

	return 0;
}


void MapResult(RCX_Result error, char * errorString) {
  if (error == 0) {
    strcpy(errorString, "OK");
    return;
  }

	switch(error)
	{
		case kRCX_OpenSerialError:
			strcpy(errorString, "Could not open serial port or USB device\n");
			break;
		case kRCX_IREchoError:
			strcpy(errorString, "Problem talking to IR device\n");
			break;
		case kRCX_ReplyError:
			if (gLink.WasErrorFromMissingFirmware()) {
				strcpy(errorString, "No firmware installed on RCX\n");
      } else {
				strcpy(errorString, "No reply from RCX\n");
			}
			break;
		case kRCX_MemFullError:
			strcpy(errorString, "Not enough free memory in RCX to download program\n");
			break;
		case kQuietError:
			break;
		case kRCX_PipeModeError:
			strcpy(errorString,"USB driver does not support -firmfast, CyberMaster, or Spybotics\n");
			break;
		case kRCX_USBUnsupportedError:
			strcpy(errorString,"USB Tower not supported\n");
			break;
			
		case kRCX_GhostNotFoundError:
			strcpy(errorString,"Ghost libraries are not installed properly\n");
			break;
		default:
      char s[32];
      sprintf(s, "Error #%d\n", -error);
			strcpy(errorString, s);
			break;
	}
}


RCX_Result AutoLink::Open()
{
	RCX_Result result;
	
	if (!fOpen)
	{
		ULong options = gTimeout & RCX_Link::kRxTimeoutMask;
		if (gVerbose) options |= RCX_Link::kVerboseMode;
		
		result = RCX_Link::Open(gTargetType, fSerialPort, options);
		if (RCX_ERROR(result)) return result;
		
		fOpen = true;
	}
	return kRCX_OK;
}


void AutoLink::Close()
{
	if (fOpen)
	{
		RCX_Link::Close();
		fOpen = false;
	}
}


RCX_Result AutoLink::Send(const RCX_Cmd *cmd, bool retry)
{
	RCX_Result result;
	
	result = Open();
	if (RCX_ERROR(result)) return result;
	
	if (retry)
	{
		result = Sync();
		if (RCX_ERROR(result)) return result;
	}

	result = RCX_Link::Send(cmd, retry);

	return retry ? result : kRCX_OK;
}


bool AutoLink::DownloadProgress(int /* soFar */, int /* total */)
{
	fputc('.', STDERR);
	fflush(STDERR);
	return true;
}


bool SameString(const char *s1, const char *s2)
{
	char c1, c2;
	
	while(true)
	{
		c1 = *s1++;
		c2 = *s2++;
		
		if (c1==0 && c2==0) return true;
		
		if (tolower(c1) != tolower(c2)) return false;
	}
}



extern "C" int __declspec(dllexport) WEP (int nParam);

extern "C" BOOL __declspec(dllexport) receive(HANDLE handle, void **data, char *types, void ***out, char **out_types, char **to_say, HINSTANCE string_library);

/*
  GLOBAL VARIABLES
  */
BOOL firstRun = true;

BOOL debugFlag = true;
/**************************************************/

int FAR PASCAL LibMain (HANDLE , WORD , WORD , LPSTR ) { 
  return 1 ; 
}

int __declspec(dllexport) WEP (int) { 
  return 1 ; 
}

char *copy_string(char *source, int length) { 
  if (source == NULL) return(NULL);
  if (length <= 0) length = strlen(source);
  char *destination = (char *) GlobalAlloc(0,length+1); // Can't use library's local storage
  memcpy(destination,source,length);
  destination[length] = '\0'; // terminate the string
  return(destination);
};


#ifdef _DEBUG
/* logDebugMessage --------------------------------- */
void logDebugMessage(char *m, char *arg) {
	if(debugFlag) {
		FILE *log = fopen("rcx\\logMessages.txt", "a+");
		fprintf(log, "%s%s;\n", m, arg);
		fclose(log);
	}
}

void logDebugMessage(char *m, long arg) {
	if(debugFlag) {
		FILE *log = fopen("rcx\\logMessages.txt", "a+");
		fprintf(log, "%s%li;\n", m, arg);
		fclose(log);
	}
}

void logDebugMessage(char *m) {
	logDebugMessage(m, "");
}
/* --------------------------------- logDebugMessage */
#endif


void ExecRawCommand(char *commandCode, void ***out, char **out_types, BOOL returningLong, BOOL isSendMessage) {
  /* PARAMETER    I/O   MEANING
     commandCode   I    the rcx opcode + parameters to be passed to the nqc as a raw spec
     out           O    the ToonTalk area to host the return value
     out_types     O    the ToonTalk area to host the return type
     returningLong I    true if the rcx command returns a number (e.g., a poll command)
     isSendMessage I    true if the command is a sendMessage

  */
  RCX_Result result = kRCX_OK;

#ifdef _DEBUG
  /*log*/ logDebugMessage("entering ExecRawCommand");
  /*log*/ logDebugMessage("commandCode == ", commandCode);
#endif

  if(isSendMessage) {
    result = SendRawCommand("10", true); // send ping w/retry
    if(result == 0) SendRawCommand(commandCode, false);  // second arg false to avoid retry
  } else {
    result = SendRawCommand(commandCode, true);  // second arg true to force retry
  }

  out[0] = (void * *) GlobalAlloc(0,sizeof(void*));

  if(result > 0) { // ok, returning a number (result actually always == 2)
    out_types[0] = copy_string("L",1);

    short sh_return_value = 0;
    sh_return_value = gLink.GetReplyByte(1) << 8;
    sh_return_value += gLink.GetReplyByte(0);

    long l_return_value = (long) sh_return_value;
    out[0][0] = (void *) l_return_value;
  } else { // returning a string
    out_types[0] = copy_string("S",1);
    char s[100];
    MapResult(result, s);
    out[0][0] = (void *) copy_string(s, strlen(s));
  }
}
 

// Here is the exported procedure for communicating with the RCX
BOOL __declspec(dllexport) receive(HANDLE handle, void **data, char *types,
																   char *label, char *country_code, 
												           void ***out, char **out_types,
																	 char **to_say, BOOL *ok_to_speak,
																	 HINSTANCE string_library) {


#ifdef _DEBUG
  /*log*/ logDebugMessage("\n*****\nentering receive - types = ");
  /*log*/ logDebugMessage(types);
#endif

  if(firstRun) {

#ifdef _DEBUG
    /*log*/ logDebugMessage("\n*****\nfirst run");
#endif

    gLink.SetSerialPort("USB");
    firstRun = false;
  }
  *ok_to_speak = true;
  if (types == NULL) { // asking for help

#ifdef _DEBUG
    /*log*/ logDebugMessage("types == NULL");
#endif

    // Set *to_say to help string
		*to_say = copy_string("Help string", 0);
    return TRUE;
  };
  char *d_command = (char *) data[0];
  BOOL isGet = false;
  BOOL isSendMessage = false;

#ifdef _DEBUG
  /*log*/ logDebugMessage("isGet = ", isGet);
#endif

  char commandCode[20]; // example: "5104" wher 51 is the opcode, 04 the (only) parameter
  if (strcmp(types,"[SSB]") == 0) {

#ifdef _DEBUG
    /*log*/ logDebugMessage("[SSB]");
    /*log*/ logDebugMessage("d_command == ", d_command);
#endif

    if (stricmp(d_command,"Set Tower Port") == 0) { // received a box with "Set Tower Port", followed by the string identifying the port, followed by a bird

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set Tower Port", (char *) data[1]);
#endif

      gLink.SetSerialPort((char *) data[1]);
     // beeps
      strcpy(commandCode, "5104");  // play sound 4
    } else if(stricmp(d_command,"Play Sound") == 0) { // received a box with "Play Sound", followed by the sound parameter, followed by a bird

#ifdef _DEBUG
      /*log*/ logDebugMessage("Play Sound");
#endif

      char *soundName = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("soundName = ", soundName);
#endif

      if(stricmp(soundName, "key click") == 0) {
        strcpy(commandCode, "5100");
      } else if(stricmp(soundName, "beep") == 0) {
        strcpy(commandCode, "5101");
      } else if(stricmp(soundName, "sweep down") == 0) {
        strcpy(commandCode, "5102");
      } else if(stricmp(soundName, "sweep up") == 0) {
        strcpy(commandCode, "5103");
      } else if(stricmp(soundName, "error") == 0) {
        strcpy(commandCode, "5104");
      } else if(stricmp(soundName, "fast sweep up") == 0) {
        strcpy(commandCode, "5105");
      } else {

#ifdef _DEBUG
        /*log*/ logDebugMessage("Play unknown sound");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(40 + strlen(soundName)));
				strcpy(m, "I do not understand this sound name: ");
				strcat(m, soundName);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
    } else if(stricmp(d_command,"Get") == 0) { // received a box with "Get", followed by the source parameter, followed by a bird

#ifdef _DEBUG
      /*log*/ logDebugMessage("Get");
#endif

      isGet = true;
      char *source = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("source = ", source);
#endif

      if(stricmp(source, "Sensor1") == 0) {
        strcpy(commandCode, "120900");
      } else if(stricmp(source, "Sensor2") == 0) {
        strcpy(commandCode, "120901");
      } else if(stricmp(source, "Sensor3") == 0) {
        strcpy(commandCode, "120902");
      } else if(stricmp(source, "Var1") == 0) {
        strcpy(commandCode, "120000");
      } else if(stricmp(source, "Var2") == 0) {
        strcpy(commandCode, "120001");
      } else if(stricmp(source, "Var3") == 0) {
        strcpy(commandCode, "120002");
      } else {
        // here deal with other sources

#ifdef _DEBUG
        /*log*/ logDebugMessage("Get unknown source");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(40 + strlen(source)));
				strcpy(m, "I do not understand this source: ");
				strcat(m, source);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
    } else if(stricmp(d_command,"Set Display") == 0) {// received a box with "Set Display", followed by the source parameter, followed by a bird

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set Display");
#endif

      char *source = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("source = ", source);
      /*log*/ logDebugMessage("isGet = ", isGet);
#endif

      if(stricmp(source, "Sensor1") == 0) {
        strcpy(commandCode, "e50000090000");
      } else if(stricmp(source, "Sensor2") == 0) {
        strcpy(commandCode, "e50000090100");
      } else if(stricmp(source, "Sensor3") == 0) {
        strcpy(commandCode, "e50000090200");
      } else if(stricmp(source, "Var1") == 0) {
        strcpy(commandCode, "e50000000000");
      } else if(stricmp(source, "Var2") == 0) {
        strcpy(commandCode, "e50000000100");
      } else if(stricmp(source, "Var3") == 0) {
        strcpy(commandCode, "e50000000200");
      } else if(stricmp(source, "Message") == 0) {
        strcpy(commandCode, "e500000f0000");
      } else {
        // here deal with other sources

#ifdef _DEBUG
        /*log*/ logDebugMessage("Set Display to unknown source");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(40 + strlen(source)));
				strcpy(m, "I do not understand this source: ");
				strcat(m, source);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
    } else if(stricmp(d_command,"On") == 0) {// received a box with "On", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("On");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "2180");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else if(stricmp(d_command,"Off") == 0) {// received a box with "Off", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Off");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "2140");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else if(stricmp(d_command,"Float") == 0) {// received a box with "Float", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Float");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "2100");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else if(stricmp(d_command,"Set Forward") == 0) {// received a box with "Set Forward", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set Forward");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "E180");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else if(stricmp(d_command,"Set Backward") == 0) {// received a box with "Set Backward", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set Backward");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "E100");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else if(stricmp(d_command,"Reverse Direction") == 0) {// received a box with "Reverse Direction", <motor-list>, bird
      char *motorList = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Reverse Direction");
      /*log*/ logDebugMessage("motorList = ", motorList);
#endif

      _strupr(motorList);
      BOOL isMotorA = (strstr(motorList, "MOTORA") != NULL);
      BOOL isMotorB = (strstr(motorList, "MOTORB") != NULL);
      BOOL isMotorC = (strstr(motorList, "MOTORC") != NULL);
      strcpy(commandCode, "E140");
      if(isMotorA) commandCode[3] += 1;
      if(isMotorB) commandCode[3] += 2;
      if(isMotorC) commandCode[3] += 4;
    } else { // here add all commands accepted

#ifdef _DEBUG
      /*log*/ logDebugMessage("SSB unknown command");
#endif

      // set *to_say to describe problem
			char* m = (char*)(malloc(40 + strlen(d_command)));
			strcpy(m, "I do not understand this command name: ");
			strcat(m, d_command);
   		*to_say = copy_string(m, 0);
			free(m);
      return FALSE;
    }
    ExecRawCommand(commandCode, out, out_types, isGet, isSendMessage);
    return TRUE;
  } else if(strcmp(types,"[SLB]") == 0) {

#ifdef _DEBUG
    /*log*/ logDebugMessage("[SLB]");
    /*log*/ logDebugMessage("d_command == ", d_command);
#endif

    if (stricmp(d_command,"Send Message") == 0) { // received a box with "Send Message", followed by the message parameter, followed by a bird
      isSendMessage = true;
      long message = (long) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Send Message");
      /*log*/ logDebugMessage("message == ", message);
#endif

      if((message > 0) && (message < 10)) {  // will become 1..255
				strcpy(commandCode, "F700");
				commandCode[3] += (char)message;  // only works for 1-digit message numbers
      } else {

#ifdef _DEBUG
        /*log*/ logDebugMessage("Send unknown message");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(80));
				strcpy(m, "I do not understand this message #: ");
        char s[40];
        _ltoa(message, s, 10);
				strcat(m, s);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
    } else { // here other SLB commands

#ifdef _DEBUG
      /*log*/ logDebugMessage("SLB unknown command");
#endif

      // set *to_say to describe problem
			char* m = (char*)(malloc(40 + strlen(d_command)));
			strcpy(m, "I do not understand this command name: ");
			strcat(m, d_command);
   		*to_say = copy_string(m, 0);
			free(m);
      return FALSE;
    }
    ExecRawCommand(commandCode, out, out_types, isGet, isSendMessage);
    return TRUE;
  } else if(strcmp(types,"[SSSB]") == 0) {

#ifdef _DEBUG
    /*log*/ logDebugMessage("[SSSB]");
    /*log*/ logDebugMessage("d_command == ", d_command);
#endif

    if (stricmp(d_command,"Set Type") == 0) { // received a box with "Set Type", sensor, type, bird
      char *sensor = (char *) data[1]; // oneof: "sensor1", "sensor2", "sensor3"
      char *type = (char *) data[2];   // oneof: "light", "touch", "termperature", "angle"

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set Type");
      /*log*/ logDebugMessage("Sensor = ", sensor);
      /*log*/ logDebugMessage("Type = ", type);
#endif

      char sNumber[3];
      if(stricmp(sensor, "sensor1") == 0) strcpy(sNumber, "00");
      else if(stricmp(sensor, "sensor2") == 0) strcpy(sNumber, "01");
      else if(stricmp(sensor, "sensor3") == 0) strcpy(sNumber, "02");
      else { // sensor spec unrecognizable

#ifdef _DEBUG
        /*log*/ logDebugMessage("Set Type of unknown sensor");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(60 + strlen(sensor)));
				strcpy(m, "I do not understand this sensor: ");
				strcat(m, sensor);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
      char sType[2];
      if(stricmp(type, "touch") == 0) strcpy(sType, "01");
      else if(stricmp(type, "temperature") == 0) strcpy(sType, "02");
      else if(stricmp(type, "light") == 0) strcpy(sType, "03");
      else if(stricmp(type, "angle") == 0) strcpy(sType, "04");
      else { // type spec unrecognizable

#ifdef _DEBUG
        /*log*/ logDebugMessage("Set Type to unknown type");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(60 + strlen(type)));
				strcpy(m, "I do not understand this type: ");
				strcat(m, type);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
      strcpy(commandCode, "32");
      strcat(commandCode, sNumber);
      strcat(commandCode, sType);
    } else { // here other SSSB commands

#ifdef _DEBUG
      /*log*/ logDebugMessage("SSSB unknown command");
#endif

      // set *to_say to describe problem
			char* m = (char*)(malloc(40 + strlen(d_command)));
			strcpy(m, "I do not understand this command name: ");
			strcat(m, d_command);
   		*to_say = copy_string(m, 0);
			free(m);
      return FALSE;
    }
    ExecRawCommand(commandCode, out, out_types, isGet, isSendMessage);
    return TRUE;
  } else if(strcmp(types,"[SSLB]") == 0) {

#ifdef _DEBUG
    /*log*/ logDebugMessage("[SSLB]");
    /*log*/ logDebugMessage("d_command == ", d_command);
#endif

    if (stricmp(d_command,"Set") == 0) { // received a box with "Set", variable, value, bird
      char *dest = (char *) data[1];

#ifdef _DEBUG
      /*log*/ logDebugMessage("Set");
      /*log*/ logDebugMessage("dest = ", dest);
#endif

      if(stricmp(dest, "Var1") == 0) {
        strcpy(commandCode, "140002");
      } else if(stricmp(dest, "Var2") == 0) {
        strcpy(commandCode, "140102");
      } else if(stricmp(dest, "Var3") == 0) {
        strcpy(commandCode, "140202");
      } else {
        // here deal with other destinations

#ifdef _DEBUG
        /*log*/ logDebugMessage("Set unknown destination");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(40 + strlen(dest)));
				strcpy(m, "I do not understand this destination: ");
				strcat(m, dest);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 
      }
      char sValue[5];
      long value = (long) data[2];
      if((value < -32767) || (value > 32767)) { // value out of range

#ifdef _DEBUG
        /*log*/ logDebugMessage("Set unknown destination");
#endif

        // set *to_say to describe problem
				char* m = (char*)(malloc(80));
				sprintf(m, "Value is out of range: %ld", value);
    		*to_say = copy_string(m, 0);
				free(m);
        return FALSE; 

      }
      short sh = (short) value;
      char s1[5];
      sprintf(s1, "%04hx", sh);
      sValue[0] = s1[2];
      sValue[1] = s1[3];
      sValue[2] = s1[0];
      sValue[3] = s1[1];
      sValue[4] = '\0';
      strcat(commandCode, sValue);
    }
    ExecRawCommand(commandCode, out, out_types, isGet, isSendMessage);
    return TRUE;
  } else {  // types is not recognized

#ifdef _DEBUG
    /*log*/ logDebugMessage("neither SSB nor SLB type");
#endif

		*to_say = copy_string("You should give the RCX foreign bird a three-hole-box with a string in the first box, a string or a number in the second, and a bird in the third", 0);
    return FALSE;
  }
  // Should never fall here

#ifdef _DEBUG
  /*log*/ logDebugMessage("should never fall here");
#endif

  return FALSE;
}
